from django.urls import path

from . import views
urlpatterns=[
    path('', views.icon,name='icon'),
    path('signup/', views.signup,name='signup'),
    path('index/',views.index,name='index'),
    path('transfer/',views.transfer,name='transfer'),
    path('pay/', views.upi_payment, name='upi_payment'),
    path('paycontact/', views.pay_contacts, name='pay_contacts'),
    path('bank-details/', views.bank_details, name='bank_details'),
    path('transaction_history_screen/', views.transaction_history_screen, name='transaction_history_screen'),
    path('self_help_groups/', views.self_help_groups, name='self_help_groups'),
    path('dash/',views.dash,name='dash'),
    path('self_help_gr2/',views.self_help_gr2,name='self_help_gr2'),
    path('self_help_payment/', views.self_help_payment, name='self_help_payment'),
    path('profile/', views.profile, name='profile'),
    path('self_help_select_method/', views.self_help_select_method, name='self_help_select_method'),
    path('self_help_pay_upi/', views.upi_payment, name='self_help_pay_upi'),
    path('self_help_pay_contact/', views.pay_contacts, name='self_help_pay_contact'),
    path('self_help_pay_bank/', views.transfer, name='self_help_pay_bank'),
    path('personal-info/', views.personal_info, name='personal_info'),
]