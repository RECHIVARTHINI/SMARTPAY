import random
from django.shortcuts import render, redirect
from firebase_admin import firestore
import string
from django.core.mail import send_mail
from django.conf import settings
from django.http import JsonResponse, HttpResponse, HttpResponseNotAllowed

from django.views.decorators.csrf import csrf_exempt
from django.core.mail import send_mail 

db=firestore.client()

def index(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        # Get user from Firebase
        users = db.collection('signup').get()
        user_found = False
        
        for user in users:
            user_data = user.to_dict()
            if user_data['email'] == email:
                user_found = True
                if user_data['password'] == password:
                    # Store user data in session
                    request.session['user'] = email
                    request.session['username'] = user_data['username']
                    request.session['balance'] = user_data.get('balance', 0)
                    
                    # Get user's banking details if they exist
                    banking_details = db.collection('banking_details').where('email', '==', email).get()
                    if banking_details:
                        bank_data = banking_details[0].to_dict()
                        request.session['account_number'] = bank_data.get('account_number')
                        request.session['bank_name'] = bank_data.get('bank_name')
                    
                    return redirect('dash')
                else:
                    return render(request, 'index.html', {
                        'message': 'Incorrect password',
                        'email': email
                    })
        
        if not user_found:
            return render(request, 'index.html', {
                'message': 'Email not found. Please sign up first.'
            })
            
    return render(request, 'index.html')

def signup(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Check for duplicate username or email
        existing_users = db.collection('signup').where('username', '==', username).get()
        existing_emails = db.collection('signup').where('email', '==', email).get()
        if existing_users:
            return render(request, 'signuppage.html', {'error': 'Username already exists. Please choose another.'})
        if existing_emails:
            return render(request, 'signuppage.html', {'error': 'Email already registered. Please use another email.'})

        # Create user document with initial balance
        db.collection('signup').document(username).set({
            'username': username,
            'email': email,
            'password': password,
            'balance': 50000  # Initial balance
        })
        
        # Create initial transaction record
        db.collection('transactions').add({
            'username': username,
            'type': 'initial_balance',
            'amount': 50000,
            'timestamp': firestore.SERVER_TIMESTAMP,
            'status': 'completed',
            'description': 'Initial balance credited'
        })
        
        # Redirect to personal information page
        return redirect('personal_info')
    return render(request, 'signuppage.html')

def transfer(request):
    if request.method == 'POST':
        accno = request.POST.get('accno')
        ifsc = request.POST.get('ifsc').upper()
        amount = float(request.POST.get('amount'))
        pin = request.POST.get('pin')
        username = request.session.get('user')
        group_id = request.POST.get('group_id')
        group_name = request.POST.get('group_name')
        
        # Validate account number (9-18 digits)
        if not accno.isdigit() or len(accno) < 9 or len(accno) > 18:
            return render(request, 'transfer.html', {'error': 'Invalid account number. Must be 9-18 digits.'})
        
        # Validate IFSC code (4 letters + 0 + 6 alphanumeric)
        import re
        ifsc_pattern = re.compile(r'^[A-Z]{4}0[A-Z0-9]{6}$')
        if not ifsc_pattern.match(ifsc):
            return render(request, 'transfer.html', {'error': 'Invalid IFSC code. Format: BANK0123456'})
        
        # Get user's current balance
        user_doc = db.collection('signup').where('email', '==', username).get()
        if not user_doc:
            return render(request, 'transfer.html', {'error': 'User not found'})
            
        user_data = user_doc[0].to_dict()
        current_balance = user_data.get('balance', 0)
        
        if current_balance < amount:
            return render(request, 'transfer.html', {'error': 'Insufficient balance'})
        
        # Update user's balance
        new_balance = current_balance - amount
        db.collection('signup').document(user_data['username']).update({
            'balance': new_balance
        })
        
        # If group contribution, update group and record as group_deposit
        if group_id:
            group_ref = db.collection('self_help_groups').document(group_id)
            group_data = group_ref.get().to_dict()
            if group_data:
                new_group_amount = group_data.get('current_amount', 0) + amount
                group_ref.update({'current_amount': new_group_amount})
            db.collection('transactions').add({
                'username': user_data['username'],
                'type': 'group_deposit',
                'amount': amount,
                'group_id': group_id,
                'group_name': group_data.get('name') if group_data else group_name,
                'timestamp': firestore.SERVER_TIMESTAMP,
                'status': 'completed',
                'description': f'Group bank transfer to {accno} for {group_data.get("name") if group_data else group_name}',
                'payment_method': 'bank_transfer',
                'is_debit': True
            })
            request.session['balance'] = new_balance
            return redirect('self_help_gr2')
        else:
            # Record normal bank transfer
            db.collection('transactions').add({
                'username': user_data['username'],
                'type': 'bank_transfer',
                'amount': amount,
                'recipient_account': accno,
                'ifsc': ifsc,
                'timestamp': firestore.SERVER_TIMESTAMP,
                'status': 'completed',
                'description': f'Bank transfer to account {accno}'
            })
            request.session['balance'] = new_balance
            return redirect('dash')
    
    # Pre-fill for group contribution
    group_id = request.GET.get('group_id')
    amount = request.GET.get('amount')
    group_name = request.GET.get('group_name')
    context = {}
    if group_id and amount:
        context['group_id'] = group_id
        context['amount'] = amount
        context['group_name'] = group_name
    return render(request, 'transfer.html', context)

def upi_payment(request):
    if request.method == 'POST':
        upi_id = request.POST.get('upiID')
        amount = float(request.POST.get('amount'))
        pin = request.POST.get('pin')
        username = request.session.get('user')
        group_id = request.POST.get('group_id')
        group_name = request.POST.get('group_name')
        
        # Validate UPI ID format
        import re
        upi_pattern = re.compile(r'^[a-zA-Z0-9._-]+@[a-zA-Z]{3,}$')
        if not upi_pattern.match(upi_id):
            return render(request, 'upi.html', {'error': 'Invalid UPI ID format. Please use format: username@bankname'})
        
        # Get user's current balance
        user_doc = db.collection('signup').where('email', '==', username).get()
        if not user_doc:
            return render(request, 'upi.html', {'error': 'User not found'})
            
        user_data = user_doc[0].to_dict()
        current_balance = user_data.get('balance', 0)
        
        if current_balance < amount:
            return render(request, 'upi.html', {'error': 'Insufficient balance'})
        
        # Update user's balance
        new_balance = current_balance - amount
        db.collection('signup').document(user_data['username']).update({
            'balance': new_balance
        })
        
        # If group contribution, update group and record as group_deposit
        if group_id:
            group_ref = db.collection('self_help_groups').document(group_id)
            group_data = group_ref.get().to_dict()
            if group_data:
                new_group_amount = group_data.get('current_amount', 0) + amount
                group_ref.update({'current_amount': new_group_amount})
            db.collection('transactions').add({
                'username': user_data['username'],
                'type': 'group_deposit',
                'amount': amount,
                'group_id': group_id,
                'group_name': group_data.get('name') if group_data else group_name,
                'timestamp': firestore.SERVER_TIMESTAMP,
                'status': 'completed',
                'description': f'Group UPI payment to {upi_id} for {group_data.get("name") if group_data else group_name}',
                'payment_method': 'upi',
                'is_debit': True
            })
            request.session['balance'] = new_balance
            return redirect('transaction_history_screen')
        else:
            # Record normal UPI transaction
            db.collection('transactions').add({
                'username': user_data['username'],
                'type': 'upi_payment',
                'amount': amount,
                'upi_id': upi_id,
                'timestamp': firestore.SERVER_TIMESTAMP,
                'status': 'completed',
                'description': f'UPI payment to {upi_id}'
            })
            request.session['balance'] = new_balance
            return redirect('dash')
    
    # Pre-fill for group contribution
    group_id = request.GET.get('group_id')
    amount = request.GET.get('amount')
    group_name = request.GET.get('group_name')
    context = {}
    if group_id and amount:
        context['group_id'] = group_id
        context['amount'] = amount
        context['group_name'] = group_name
    return render(request, 'upi.html', context)

def pay_contacts(request):
    if request.method == 'POST':
        contact = request.POST.get('contact')
        amount = float(request.POST.get('amount'))
        pin = request.POST.get('pin')
        username = request.session.get('user')
        group_id = request.POST.get('group_id')
        group_name = request.POST.get('group_name')
        
        if not contact or not amount or not pin:
            return render(request, 'paycontact.html', {'error': 'All fields are required.'})
            
        # Get user's current balance
        user_doc = db.collection('signup').where('email', '==', username).get()
        if not user_doc:
            return render(request, 'paycontact.html', {'error': 'User not found'})
            
        user_data = user_doc[0].to_dict()
        current_balance = user_data.get('balance', 0)
        
        if current_balance < amount:
            return render(request, 'paycontact.html', {'error': 'Insufficient balance'})
        
        # Update user's balance
        new_balance = current_balance - amount
        db.collection('signup').document(user_data['username']).update({
            'balance': new_balance
        })
        
        # If group contribution, update group and record as group_deposit
        if group_id:
            group_ref = db.collection('self_help_groups').document(group_id)
            group_data = group_ref.get().to_dict()
            if group_data:
                new_group_amount = group_data.get('current_amount', 0) + amount
                group_ref.update({'current_amount': new_group_amount})
            db.collection('transactions').add({
                'username': user_data['username'],
                'type': 'group_deposit',
                'amount': amount,
                'group_id': group_id,
                'group_name': group_data.get('name') if group_data else group_name,
                'timestamp': firestore.SERVER_TIMESTAMP,
                'status': 'completed',
                'description': f'Group contact payment to {contact} for {group_data.get("name") if group_data else group_name}',
                'payment_method': 'contact',
                'is_debit': True
            })
            request.session['balance'] = new_balance
            return redirect('self_help_gr2')
        else:
            # Record normal contact payment
            db.collection('transactions').add({
                'username': user_data['username'],
                'type': 'contact_payment',
                'amount': amount,
                'recipient': contact,
                'timestamp': firestore.SERVER_TIMESTAMP,
                'status': 'completed',
                'description': f'Payment to contact {contact}'
            })
            request.session['balance'] = new_balance
            return redirect('dash')
    
    # Pre-fill for group contribution
    group_id = request.GET.get('group_id')
    amount = request.GET.get('amount')
    group_name = request.GET.get('group_name')
    context = {}
    if group_id and amount:
        context['group_id'] = group_id
        context['amount'] = amount
        context['group_name'] = group_name
    return render(request, 'paycontact.html', context)

def icon (request):
    return render(request, 'icon.html')

def bank_details(request):
    if request.method == 'POST':
        account_number = request.POST.get('account_number')
        ifsc = request.POST.get('ifsc')
        bank_name = request.POST.get('bank_name')
        pin = request.POST.get('pin')

        db.collection('banking_details').document(account_number).set({
            'account_number': account_number,
            'ifsc': ifsc,
            'bank_name': bank_name,
            'pin': pin  
        })
        return redirect('dash')
    return render(request, 'bank_details.html')


def transaction_history_screen(request):
    username = request.session.get('user')
    if not username:
        return redirect('index')
        
    # Get user's current balance
    user_doc = db.collection('signup').where('email', '==', username).get()
    if not user_doc:
        return redirect('index')
        
    user_data = user_doc[0].to_dict()
    current_balance = user_data.get('balance', 0)
    
    try:
        # Get all transactions for the user
        transactions = db.collection('transactions').where('username', '==', user_data['username']).order_by('timestamp', direction=firestore.Query.DESCENDING).get()
    except Exception as e:
        # If index is not ready, get transactions without ordering
        transactions = db.collection('transactions').where('username', '==', user_data['username']).get()
    
    transaction_list = []
    total_transactions = 0
    sum_transactions = 0
    
    # Get filter parameters
    year_filter = request.GET.get('year', 'all')
    date_filter = request.GET.get('date', '')
    search_query = request.GET.get('search', '').lower()
    
    for transaction in transactions:
        transaction_data = transaction.to_dict()
        
        # Apply filters
        if year_filter != 'all':
            transaction_year = transaction_data.get('timestamp', '').strftime('%Y') if hasattr(transaction_data.get('timestamp', ''), 'strftime') else ''
            if transaction_year != year_filter:
                continue
                
        if date_filter:
            transaction_date = transaction_data.get('timestamp', '').strftime('%Y-%m-%d') if hasattr(transaction_data.get('timestamp', ''), 'strftime') else ''
            if transaction_date != date_filter:
                continue
                
        if search_query:
            # Search in description and type
            description = transaction_data.get('description', '').lower()
            transaction_type = transaction_data.get('type', '').lower()
            if search_query not in description and search_query not in transaction_type:
                continue
        
        transaction_list.append(transaction_data)
        total_transactions += 1
        sum_transactions += transaction_data.get('amount', 0)
    
    # Sort transactions by timestamp in memory if index wasn't available
    if 'timestamp' in transaction_list[0] if transaction_list else False:
        transaction_list.sort(key=lambda x: x.get('timestamp', 0), reverse=True)
    
    # Get unique years for the year filter
    years = set()
    for transaction in transactions:
        timestamp = transaction.to_dict().get('timestamp')
        if hasattr(timestamp, 'strftime'):
            years.add(timestamp.strftime('%Y'))
    years = sorted(list(years), reverse=True)
    
    context = {
        'transactions': transaction_list,
        'current_balance': current_balance,
        'total_transactions': total_transactions,
        'sum_transactions': sum_transactions,
        'years': years,
        'selected_year': year_filter,
        'selected_date': date_filter,
        'search_query': search_query
    }
    
    return render(request, 'transaction_history_screen.html', context)

def self_help_groups(request):
    return render(request, 'self_help_groups.html')

def dash(request):
    # Check if user is logged in
    if 'user' not in request.session:
        return redirect('index')
        
    # Get user data from session
    user_data = {
        'email': request.session.get('user'),
        'username': request.session.get('username'),
        'balance': request.session.get('balance', 0)
    }
    
    return render(request, 'dash.html', user_data)

group_data = {
    'balance': 0,
    'members': []
}

@csrf_exempt
def self_help_gr2(request):
    if request.method == 'GET':
        # Get group details from Firebase
        group_id = request.GET.get('group_id', 'women_empowerment')  # Default to women empowerment group
        group_data = db.collection('self_help_groups').document(group_id).get().to_dict()
        
        if not group_data:
            # Default group data if not found
            group_data = {
                'name': 'Women Empowerment',
                'target_amount': 50000,
                'monthly_contribution': 5000,
                'current_amount': 30000,
                'members': [
                    {'name': 'Member 1', 'contribution': 5000},
                    {'name': 'Member 2', 'contribution': 5000},
                    {'name': 'Member 3', 'contribution': 5000}
                ]
            }
        
        # Calculate progress percentage
        progress_percentage = (group_data.get('current_amount', 0) / group_data.get('target_amount', 1)) * 100
        
        # Check if withdrawal is allowed
        can_withdraw = group_data.get('current_amount', 0) >= group_data.get('target_amount', 0)
        
        context = {
            'group_name': group_data.get('name'),
            'target_amount': group_data.get('target_amount'),
            'monthly_contribution': group_data.get('monthly_contribution'),
            'current_amount': group_data.get('current_amount'),
            'members': group_data.get('members', []),
            'progress_percentage': progress_percentage,
            'can_withdraw': can_withdraw
        }
        
        return render(request, 'self_help_gr2.html', context)

    elif request.method == 'POST':
        action = request.POST.get('action')
        group_id = request.POST.get('group_id', 'women_empowerment')
        
        if action == 'deposit':
            try:
                amount = float(request.POST.get('amount'))
                group_ref = db.collection('self_help_groups').document(group_id)
                group_data = group_ref.get().to_dict()
                
                if not group_data:
                    return JsonResponse({'status': 'error', 'message': 'Group not found'})
                
                # Update group balance
                new_amount = group_data.get('current_amount', 0) + amount
                group_ref.update({
                    'current_amount': new_amount
                })
                
                # Record transaction
                db.collection('transactions').add({
                    'type': 'group_deposit',
                    'amount': amount,
                    'group_id': group_id,
                    'timestamp': firestore.SERVER_TIMESTAMP,
                    'status': 'completed'
                })
                
                return JsonResponse({'status': 'success', 'new_amount': new_amount})
            except Exception as e:
                return JsonResponse({'status': 'error', 'message': str(e)})

        elif action == 'withdraw':
            try:
                amount = float(request.POST.get('amount'))
                group_ref = db.collection('self_help_groups').document(group_id)
                group_data = group_ref.get().to_dict()
                
                if not group_data:
                    return JsonResponse({'status': 'error', 'message': 'Group not found'})
                
                # Check if target amount is reached
                if group_data.get('current_amount', 0) < group_data.get('target_amount', 0):
                    return JsonResponse({'status': 'error', 'message': 'Target amount not reached'})
                
                # Check if enough balance
                if group_data.get('current_amount', 0) < amount:
                    return JsonResponse({'status': 'error', 'message': 'Insufficient balance'})
                
                # Update group balance
                new_amount = group_data.get('current_amount', 0) - amount
                group_ref.update({
                    'current_amount': new_amount
                })
                
                # Record transaction
                db.collection('transactions').add({
                    'type': 'group_withdrawal',
                    'amount': amount,
                    'group_id': group_id,
                    'timestamp': firestore.SERVER_TIMESTAMP,
                    'status': 'completed'
                })
                
                return JsonResponse({'status': 'success', 'new_amount': new_amount})
            except Exception as e:
                return JsonResponse({'status': 'error', 'message': str(e)})

    return HttpResponseNotAllowed(['GET', 'POST'])

def profile(request):
    if 'email' not in request.session:
        return redirect('index')
    
    email = request.session['email']
    username = request.session.get('username', '')
    balance = request.session.get('balance', 0)
    bank_name = request.session.get('bank_name', '')
    
    # Get user's transactions from Firebase
    transactions = db.child("transactions").order_by_child("user_email").equal_to(email).get().val()
    
    # Calculate total transactions and amount spent
    total_transactions = 0
    total_spent = 0
    if transactions:
        for transaction in transactions.values():
            if transaction.get('type') == 'debit':
                total_spent += float(transaction.get('amount', 0))
            total_transactions += 1
    
    context = {
        'username': username,
        'email': email,
        'balance': balance,
        'bank_name': bank_name,
        'total_transactions': total_transactions,
        'total_spent': total_spent
    }
    
    return render(request, 'profile.html', context)

def self_help_payment(request):
    if request.method == 'GET':
        group_id = request.GET.get('group_id')
        amount = float(request.GET.get('amount', 0))
        username = request.session.get('user')
        
        if not username:
            return redirect('index')
            
        # Get user's current balance
        user_doc = db.collection('signup').where('email', '==', username).get()
        if not user_doc:
            return redirect('index')
            
        user_data = user_doc[0].to_dict()
        current_balance = user_data.get('balance', 0)
        
        # Get group details
        group_ref = db.collection('self_help_groups').document(group_id)
        group_data = group_ref.get().to_dict()
        
        if not group_data:
            return redirect('self_help_groups')
            
        context = {
            'group_id': group_id,
            'group_name': group_data.get('name'),
            'amount': amount,
            'user_balance': current_balance
        }
        
        return render(request, 'self_help_payment.html', context)
        
    elif request.method == 'POST':
        group_id = request.POST.get('group_id')
        amount = float(request.POST.get('amount', 0))
        pin = request.POST.get('pin')
        username = request.session.get('user')
        
        if not username:
            return redirect('index')
            
        # Get user's current balance
        user_doc = db.collection('signup').where('email', '==', username).get()
        if not user_doc:
            return redirect('index')
            
        user_data = user_doc[0].to_dict()
        current_balance = user_data.get('balance', 0)
        
        # Verify PIN (you should implement proper PIN verification)
        if pin != user_data.get('pin', '0000'):  # Replace with actual PIN verification
            return render(request, 'self_help_payment.html', {
                'error': 'Invalid PIN',
                'group_id': group_id,
                'amount': amount,
                'user_balance': current_balance
            })
        
        # Check if user has sufficient balance
        if current_balance < amount:
            return render(request, 'self_help_payment.html', {
                'error': 'Insufficient balance',
                'group_id': group_id,
                'amount': amount,
                'user_balance': current_balance
            })
        
        try:
            # Update user's balance
            new_balance = current_balance - amount
            db.collection('signup').document(user_data['username']).update({
                'balance': new_balance
            })
            
            # Update group balance
            group_ref = db.collection('self_help_groups').document(group_id)
            group_data = group_ref.get().to_dict()
            new_group_amount = group_data.get('current_amount', 0) + amount
            group_ref.update({
                'current_amount': new_group_amount
            })
            
            # Record transaction with detailed information
            transaction_data = {
                'username': user_data['username'],
                'email': username,
                'type': 'group_deposit',
                'amount': amount,
                'group_id': group_id,
                'group_name': group_data.get('name'),
                'timestamp': firestore.SERVER_TIMESTAMP,
                'status': 'completed',
                'description': f'Contribution to {group_data.get("name")} group',
                'balance_after': new_balance,
                'transaction_id': ''.join(random.choices(string.ascii_uppercase + string.digits, k=10)),
                'category': 'self_help_group',
                'payment_method': 'wallet',
                'recipient': group_data.get('name'),
                'is_debit': True
            }
            
            # Add transaction to database
            db.collection('transactions').add(transaction_data)
            
            # Update session balance
            request.session['balance'] = new_balance
            
            return redirect('self_help_gr2')
            
        except Exception as e:
            return render(request, 'self_help_payment.html', {
                'error': str(e),
                'group_id': group_id,
                'amount': amount,
                'user_balance': current_balance
            })
            
    return HttpResponseNotAllowed(['GET', 'POST'])

def self_help_select_method(request):
    group_id = request.GET.get('group_id')
    amount = request.GET.get('amount')
    context = {
        'group_id': group_id,
        'amount': amount
    }
    return render(request, 'self_help_select_method.html', context)

# New view for personal information page
def personal_info(request):
    if request.method == 'POST':
        # Get the current user's profile
        user_profile = UserProfile.objects.get(user=request.user)
        # Update profile with new personal information
        user_profile.mobile_number = request.POST.get('mobile_number')
        user_profile.date_of_birth = request.POST.get('date_of_birth')
        user_profile.gender = request.POST.get('gender')
        user_profile.permanent_address = request.POST.get('permanent_address')
        user_profile.communication_address = request.POST.get('communication_address')
        user_profile.save()
        return redirect('bank_details')
    return render(request, 'personal_info.html')